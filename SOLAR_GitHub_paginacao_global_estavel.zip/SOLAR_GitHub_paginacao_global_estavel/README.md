Versão com correção estrutural de paginação para PDF.
- remove fundos contínuos de contêineres longos na impressão;
- remove overflow:hidden de protocolos fragmentáveis;
- elimina quebra forçada antes de “Seu tratamento”;
- mantém identidade visual em cabeçalhos e cartões curtos;
- reduz o risco de páginas órfãs/fantasmas por fragmentação do Chromium.
